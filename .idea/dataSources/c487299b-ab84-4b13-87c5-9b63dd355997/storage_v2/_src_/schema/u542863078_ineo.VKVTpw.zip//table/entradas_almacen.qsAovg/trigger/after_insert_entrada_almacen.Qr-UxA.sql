create definer = root@localhost trigger after_insert_entrada_almacen
    after insert
    on entradas_almacen
    for each row
BEGIN
    DECLARE v_kardex_qty INT DEFAULT 0;
    DECLARE v_kardex_inicial INT DEFAULT 0;
    DECLARE v_id_compra VARCHAR(255);  -- Variable para almacenar el id_compra
    DECLARE v_kardex_movimiento VARCHAR(255);  -- Variable para el movimiento

    -- Verificar si id_compra es NULL o vacío
    IF NEW.id_compra IS NULL OR NEW.id_compra = '' THEN
        SET v_id_compra = NULL;  -- Asignar NULL si es NULL o vacío
        SET v_kardex_movimiento = 'Entrada Directa';  -- Movimiento "Entrada Directa"
    ELSE
        SET v_id_compra = NEW.id_compra;  -- Usar el id_compra de la entrada
        SET v_kardex_movimiento = 'Entrada Compra';  -- Movimiento "Entrada Compra"
    END IF;

    -- Insertar en la tabla kardex_almacen
    INSERT INTO kardex_almacen (
        kardex_fecha, 
        item_id, 
        kardex_lote, 
        kardex_caducidad, 
        kardex_inicial,   
        kardex_entradas,  
        kardex_salidas, 
        kardex_qty,       
        kardex_dev_stock, 
        kardex_dev_merma, 
        kardex_movimiento, 
        kardex_ubicacion, 
        kardex_destino, 
        id_usua,
        id_compra,
        factura
    )
    VALUES (
        NEW.entrada_fecha,
        NEW.item_id,
        NEW.entrada_lote,
        NEW.entrada_caducidad,
        0,
        NEW.entrada_unidosis,
        0,
        NEW.entrada_unidosis,
        0,
        0,
        v_kardex_movimiento,  -- Usar el movimiento dinámico
        NEW.ubicacion_id,
        '',
        NEW.id_usua,
        v_id_compra,  -- Usar la variable v_id_compra, que puede ser NULL
        NEW.factura
    );

END;

