create definer = root@localhost trigger after_insert_merma_almacenh
    after insert
    on merma_almacenh
    for each row
BEGIN
    DECLARE cantidad_inicial INT DEFAULT 0;

    
    SELECT kardex_qty INTO cantidad_inicial
    FROM kardex_almacenh
    WHERE item_id = NEW.item_id
    AND kardex_lote = NEW.merma_lote
    ORDER BY kardex_fecha DESC
    LIMIT 1;

    
    IF cantidad_inicial >= NEW.merma_qty THEN
        
        INSERT INTO kardex_almacenh (
            kardex_fecha, 
            item_id, 
            kardex_lote, 
            kardex_caducidad, 
            kardex_inicial, 
            kardex_entradas, 
            kardex_salidas, 
            kardex_qty, 
            kardex_dev_stock, 
            kardex_dev_merma, 
            kardex_movimiento, 
            kardex_ubicacion, 
            kardex_destino, 
            id_usua
        ) VALUES (
            NEW.merma_fecha, 
            NEW.item_id, 
            NEW.merma_lote, 
            NEW.merma_caducidad, 
            cantidad_inicial,  
            0,                
            NEW.merma_qty,    
            cantidad_inicial - NEW.merma_qty, 
            0,                
            NEW.merma_qty,    
            'Merma',         
            NEW.ubicacion_id, 
            '',               
            NEW.id_usua      
        );
    ELSE
        
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error en la merma. Stock inicial no disponible para el lote.';
    END IF;
END;

