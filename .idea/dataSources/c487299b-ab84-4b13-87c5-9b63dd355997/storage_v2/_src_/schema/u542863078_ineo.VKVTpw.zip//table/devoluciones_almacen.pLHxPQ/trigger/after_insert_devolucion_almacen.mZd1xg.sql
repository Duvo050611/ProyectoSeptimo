create definer = root@localhost trigger after_insert_devolucion_almacen
    after insert
    on devoluciones_almacen
    for each row
BEGIN
    DECLARE cantidad_actual INT;

    
    SELECT kardex_qty 
    INTO cantidad_actual
    FROM kardex_almacen
    WHERE item_id = NEW.item_id
      AND kardex_lote = NEW.devolucion_lote
      AND kardex_caducidad = NEW.devolucion_caducidad
      AND kardex_ubicacion = NEW.ubicacion_id
    ORDER BY kardex_fecha DESC
    LIMIT 1;  

    
    IF cantidad_actual IS NULL THEN
        SET cantidad_actual = 0;
    END IF;

    
    INSERT INTO kardex_almacen (
        kardex_fecha, 
        item_id, 
        kardex_lote, 
        kardex_caducidad, 
        kardex_inicial, 
        kardex_entradas, 
        kardex_salidas, 
        kardex_qty, 
        kardex_dev_stock, 
        kardex_dev_merma, 
        kardex_movimiento, 
        kardex_ubicacion, 
        kardex_destino, 
        id_usua
    ) VALUES (
        NEW.devolucion_fecha,                       
        NEW.item_id,                                
        NEW.devolucion_lote,                        
        NEW.devolucion_caducidad,                   
        cantidad_actual,                            
        0,                                          
        0,                                          
        cantidad_actual + NEW.devolucion_qty,        
        NEW.devolucion_qty,                         
        0,                                          
        'Devolución',                               
        NEW.ubicacion_id,                           
        '',                                         
        NEW.id_usua                                 
    );
END;

