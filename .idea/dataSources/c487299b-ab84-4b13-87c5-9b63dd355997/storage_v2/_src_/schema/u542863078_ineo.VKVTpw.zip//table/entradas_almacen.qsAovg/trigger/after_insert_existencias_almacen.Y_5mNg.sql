create definer = root@localhost trigger after_insert_existencias_almacen
    after insert
    on entradas_almacen
    for each row
BEGIN
    DECLARE v_existe_qty INT DEFAULT 0;
    DECLARE v_existe_entradas INT DEFAULT 0;
    DECLARE v_existe_inicial INT DEFAULT 0;
    DECLARE v_count INT DEFAULT 0;

    
    SELECT COUNT(*), COALESCE(MAX(existe_qty), 0), COALESCE(MAX(existe_entradas), 0)
    INTO v_count, v_existe_qty, v_existe_entradas
    FROM existencias_almacen
    WHERE item_id = NEW.item_id
    AND existe_lote = NEW.entrada_lote
    AND existe_caducidad = NEW.entrada_caducidad;

    IF v_count > 0 THEN
        
        SET v_existe_inicial = v_existe_qty;
        SET v_existe_qty = v_existe_qty + NEW.entrada_unidosis;
        SET v_existe_entradas = v_existe_entradas + NEW.entrada_unidosis;

        UPDATE existencias_almacen
        SET 
            existe_qty = v_existe_qty,
            existe_entradas = v_existe_entradas,
            existe_fecha = NOW()
        WHERE 
            item_id = NEW.item_id
            AND existe_lote = NEW.entrada_lote
            AND existe_caducidad = NEW.entrada_caducidad;

    ELSE
        
        INSERT INTO existencias_almacen (
            item_id,
            existe_lote,
            existe_caducidad,
            existe_inicial,
            existe_entradas,
            existe_qty,
            existe_fecha,
            ubicacion_id,
            id_usua,
            existe_salidas,
            existe_devoluciones
        )
        VALUES (
            NEW.item_id,
            NEW.entrada_lote,
            NEW.entrada_caducidad,
            0,  
            NEW.entrada_unidosis,
            NEW.entrada_unidosis,
            NOW(),  
            NEW.ubicacion_id,
            NEW.id_usua,
            0,
            0
        );
    END IF;
END;

