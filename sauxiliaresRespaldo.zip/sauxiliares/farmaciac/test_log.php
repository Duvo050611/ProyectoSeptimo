<?php
// Script simple para probar el error_log
error_log("TEST: Prueba de log desde PHP - " . date('Y-m-d H:i:s'));
echo "Test de log ejecutado. Verifica el archivo error_log.";
?>
